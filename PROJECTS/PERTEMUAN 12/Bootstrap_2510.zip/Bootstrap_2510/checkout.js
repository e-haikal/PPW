(() => {
    'use strict'

    //fetch all the form
    const form = document.querySelectorAll('.needs-validaton')

    //loop over them
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopProagation()
            }

            form.classList.add('was-validated')

        }, false)
    })
})()